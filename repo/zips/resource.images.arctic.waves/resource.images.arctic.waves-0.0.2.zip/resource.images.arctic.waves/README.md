# resource.images.arctic.waves

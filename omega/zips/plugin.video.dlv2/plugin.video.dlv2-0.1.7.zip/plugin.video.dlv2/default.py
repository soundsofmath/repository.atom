if __name__ == "__main__":
    from resources.lib.main import main
    main()

import json
from modules import kodi_utils
from modules.utils import chunks
# from modules.kodi_utils import logger

SELECT = 'SELECT id FROM trakt_data'
DELETE = 'DELETE FROM trakt_data WHERE id = ?'
DELETE_LIKE = 'DELETE FROM trakt_data WHERE id LIKE ?'
WATCHED_INSERT = 'INSERT OR IGNORE INTO watched_status VALUES (?, ?, ?, ?, ?, ?)'
WATCHED_DELETE = 'DELETE FROM watched_status WHERE db_type = ?'
PROGRESS_INSERT = 'INSERT OR IGNORE INTO progress VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
PROGRESS_DELETE = 'DELETE FROM progress WHERE db_type = ?'
BASE_DELETE = 'DELETE FROM %s'
TC_BASE_GET = 'SELECT data FROM trakt_data WHERE id = ?'
TC_BASE_SET = 'INSERT OR REPLACE INTO trakt_data (id, data) VALUES (?, ?)'
TC_BASE_DELETE = 'DELETE FROM trakt_data WHERE id = ?'

class TraktCache:
	batch_size = 1000
	def __init__(self):
		self._database_connect()
		self._set_PRAGMAS()

	def set_bulk_movie_watched(self, insert_list):
		self._delete(WATCHED_DELETE, ('movie',))
		for i in chunks(insert_list, self.batch_size):
			self._executemany(WATCHED_INSERT, i)

	def set_bulk_tvshow_watched(self, insert_list):
		self._delete(WATCHED_DELETE, ('episode',))
		for i in chunks(insert_list, self.batch_size):
			self._executemany(WATCHED_INSERT, i)

	def set_bulk_movie_progress(self, insert_list):
		self._delete(PROGRESS_DELETE, ('movie',))
		self._executemany(PROGRESS_INSERT, insert_list)

	def set_bulk_tvshow_progress(self, insert_list):
		self._delete(PROGRESS_DELETE, ('episode',))
		self._executemany(PROGRESS_INSERT, insert_list)

	def _executemany(self, command, insert_list):
		self.dbcur.executemany(command, insert_list)

	def _delete(self, command, args):
		self.dbcur.execute(command, args)
#		self.dbcur.execute("""VACUUM""")

	def _database_connect(self):
		self.dbcon = kodi_utils.database_connect(kodi_utils.trakt_db, isolation_level=None)

	def _set_PRAGMAS(self):
		self.dbcur = self.dbcon.cursor()
		self.dbcur.execute("""PRAGMA synchronous = OFF""")
		self.dbcur.execute("""PRAGMA journal_mode = OFF""")
		self.dbcur.execute("""PRAGMA mmap_size = 268435456""")

def integrity_check():
	try:
		db_file = kodi_utils.translate_path(kodi_utils.trakt_db)
		with kodi_utils.database.connect(db_file) as dbcon:
			dbcur = dbcon.cursor()
			dbcur.execute("""PRAGMA integrity_check""")
			result = dbcur.fetchone()
			if 'ok' in result: status = 'passed'
			else: raise kodi_utils.database.Error(result)
			dbcur.execute("""VACUUM""")
		return status
	except kodi_utils.database.Error as e: status = str(e)
	try:
		with open(db_file, 'w') as _: pass
		from modules.cache import check_databases, clear_cache
		check_databases()
		clear_cache('trakt', silent=True)
		status = 'repaired'
	except Exception as e:
		kodi_utils.logger('database integrity error', '%s\n%s\n%s' % (status, db_file, e))
	return status

def cache_trakt_object(function, string, url):
	dbcur = TraktCache().dbcur
	dbcur.execute(TC_BASE_GET, (string,))
	cached_data = dbcur.fetchone()
	try:
		if cached_data: return json.loads(cached_data[0])
	except: pass
	result = function(url)
	dbcur.execute(TC_BASE_SET, (string, json.dumps(result)))
	return result

def reset_activity(latest_activities):
	string = 'trakt_get_activity'
	cached_data = None
	try:
		dbcur = TraktCache().dbcur
		dbcur.execute(TC_BASE_GET, (string,))
		cached_data = dbcur.fetchone()
		if cached_data: cached_data = json.loads(cached_data[0])
		else: cached_data = default_activities()
		dbcur.execute(TC_BASE_SET, (string, json.dumps(latest_activities)))
	except: pass
	return cached_data

def clear_trakt_hidden_data(list_type):
	string = 'trakt_hidden_items_%s' % list_type
	try:
		dbcur = TraktCache().dbcur
		dbcur.execute(DELETE, (string,))
	except: pass

def clear_trakt_collection_watchlist_data(list_type, mediatype):
	mediatype = 'movie' if mediatype in ('movie', 'movies') else 'tvshow'
	string = 'trakt_%s_%s' % (list_type, mediatype)
	try:
		dbcur = TraktCache().dbcur
		dbcur.execute(DELETE, (string,))
	except: pass

def clear_trakt_list_contents_data(list_type):
	string = 'trakt_list_contents_' + list_type + '_%'
	try:
		dbcur = TraktCache().dbcur
		dbcur.execute(DELETE_LIKE, (string,))
	except: pass

def clear_trakt_list_data(list_type):
	string = 'trakt_%s' % list_type
	try:
		dbcur = TraktCache().dbcur
		dbcur.execute(DELETE, (string,))
	except: pass

def clear_trakt_calendar():
	try:
		dbcur = TraktCache().dbcur
		dbcur.execute(DELETE_LIKE, ('trakt_get_my_calendar_%',))
	except: return

def clear_trakt_recommendations(mediatype):
	string = 'trakt_recommendations_%s' % (mediatype)
	try:
		dbcur = TraktCache().dbcur
		dbcur.execute(DELETE, (string,))
	except: pass

def clear_all_trakt_cache_data(refresh=True):
	try:
		dbcur = TraktCache().dbcur
		for table in ('trakt_data', 'progress', 'watched_status'):
			dbcur.execute(BASE_DELETE % table)
		dbcur.execute("""VACUUM""")
		if not refresh: return True
		from indexers.trakt_api import trakt_sync_activities_thread
		trakt_sync_activities_thread()
		return True
	except: return False

def default_activities():
	return {
			'all': '',
			'movies':
				{
				'watched_at': '',
				'collected_at': '',
				'rated_at': '',
				'watchlisted_at': '',
				'favorited_at': '',
				'recommendations_at': '',
				'commented_at': '',
				'paused_at': '',
				'hidden_at': ''
				},
			'episodes':
				{
				'watched_at': '',
				'collected_at': '',
				'rated_at': '',
				'watchlisted_at': '',
				'commented_at': '',
				'paused_at': ''
				},
			'shows':
				{
				'rated_at': '',
				'watchlisted_at': '',
				'favorited_at': '',
				'recommendations_at': '',
				'commented_at': '',
				'hidden_at': '',
				'dropped_at': ''
				},
			'seasons':
				{
				'rated_at': '',
				'watchlisted_at': '',
				'commented_at': '',
				'hidden_at': ''
				},
			'comments':
				{
				'liked_at': ''
				},
			'lists':
				{
				'liked_at': '',
				'updated_at': '',
				'commented_at': ''
				},
			'watchlist':
				{
				'updated_at': ''
				},
			'favorites':
				{
				'updated_at': ''
				},
			'recommendations':
				{
				'updated_at': ''
				},
			'account':
				{
				'settings_at': '',
				'followed_at': '',
				'following_at': '',
				'pending_at': ''
				}
			}


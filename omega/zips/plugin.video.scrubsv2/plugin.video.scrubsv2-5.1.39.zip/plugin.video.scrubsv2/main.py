# -*- coding: utf-8 -*-

from sys import argv

from resources.lib import system

system.router(argv[2])



# BINGIE

The new Titan for Kodi...
BINGIE simulates Netflix's UI/UX for Kodi users.

# Terms of use
With the installation of the skin you agree that you don't use it in combination with blacklisted and illegal Kodi add-ons. I'm not associated with any available build and I won't give any support to blacklisted, banned or illegal third party addons.

# License
This work has been released under GNU General Public License v2.0.

# IMPORTANT NOTE FOR USERS
The content here is for developing purposes!
Please install the skin through the official bingie repository for updates and the supported addons required!
https://github.com/cartmandos/repository.bingie

Join the official thread for updates: https://forum.kodi.tv/showthread.php?tid=334820
